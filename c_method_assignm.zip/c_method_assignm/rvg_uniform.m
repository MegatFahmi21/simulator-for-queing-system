function output = rvg_uniform(n)

    output = floor(1+100*rand(1,n));
